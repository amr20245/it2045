using Microsoft.Maui.Controls;

namespace NewsApp;

/// <summary>
/// The root application class. Initializes the component tree and sets the
/// starting page to a NavigationPage wrapping our NewsHomePage. Using
/// NavigationPage enables push/pop navigation across the app.
/// </summary>
public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // Set the main page as a NavigationPage containing our home page.
        // This enables stack‑based navigation throughout the app.
        MainPage = new NavigationPage(new Pages.NewsHomePage());
    }
}