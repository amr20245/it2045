using Microsoft.Maui.Controls;
using NewsApp.Models;

namespace NewsApp.Pages;

/// <summary>
/// Displays the details of a single news article. The constructor accepts
/// a NewsArticle object and populates the UI elements accordingly.
/// </summary>
public partial class NewsDetailPage : ContentPage
{
    private readonly NewsArticle _article;

    public NewsDetailPage(NewsArticle article)
    {
        InitializeComponent();
        _article = article;
        // Populate UI from the article. Use the description if the content is
        // null or empty to ensure something is shown.
        ArticleImage.Source = article.ImageUrl;
        ArticleTitle.Text = article.Title;
        ArticleContent.Text = string.IsNullOrWhiteSpace(article.Content) ? article.Description : article.Content;
    }
}