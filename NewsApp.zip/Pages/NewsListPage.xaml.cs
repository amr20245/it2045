using Microsoft.Maui.Controls;
using NewsApp.Models;
using NewsApp.Services;

namespace NewsApp.Pages;

/// <summary>
/// Shows a collection of news articles for a particular category. When an
/// article is selected the app navigates to NewsDetailPage. The page title
/// reflects the selected category.
/// </summary>
public partial class NewsListPage : ContentPage
{
    private readonly GNewsService _service = new();
    private readonly string _category;

    public NewsListPage(string category)
    {
        InitializeComponent();
        _category = category;
        // Capitalize the first letter of the category for the page title.
        Title = char.ToUpper(category[0]) + category.Substring(1);
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        // Fetch articles from the service. If no API key has been configured
        // an empty list will be returned and the UI will show nothing.
        var articles = await _service.GetTopHeadlinesAsync(_category);
        NewsCollection.ItemsSource = articles;
    }

    private async void OnItemSelected(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is NewsArticle selectedArticle)
        {
            await Navigation.PushAsync(new NewsDetailPage(selectedArticle));
            ((CollectionView)sender).SelectedItem = null;
        }
    }
}