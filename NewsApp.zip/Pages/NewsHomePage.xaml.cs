using System.Collections.Generic;
using Microsoft.Maui.Controls;

namespace NewsApp.Pages;

/// <summary>
/// The landing page for the application. Presents the user with a list of
/// categories. When a category is selected the app navigates to
/// NewsListPage and passes the selected category.
/// </summary>
public partial class NewsHomePage : ContentPage
{
    /// <summary>
    /// A list of category names that will be bound to the CollectionView.
    /// </summary>
    public List<string> Categories { get; } = new()
    {
        "business",
        "entertainment",
        "general",
        "health",
        "science",
        "sports",
        "technology"
    };

    public NewsHomePage()
    {
        InitializeComponent();
        // Bind the Categories property to the page so the CollectionView can
        // display the list without requiring a ViewModel.
        BindingContext = this;
    }

    private async void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // When a category is selected we push the NewsListPage onto the
        // navigation stack. The selected item from the CollectionView is
        // passed as a string parameter to the constructor.
        if (e.CurrentSelection.FirstOrDefault() is string selectedCategory)
        {
            await Navigation.PushAsync(new NewsListPage(selectedCategory));
            // Clear the selection so the item doesn't remain highlighted.
            ((CollectionView)sender).SelectedItem = null;
        }
    }
}