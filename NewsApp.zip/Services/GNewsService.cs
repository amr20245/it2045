using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using NewsApp.Models;

namespace NewsApp.Services;

/// <summary>
/// Service responsible for retrieving news articles from the GNews API. This
/// class encapsulates the details of constructing the API request, sending
/// it, and parsing the JSON response into C# objects. Consumers of this
/// service can call <see cref="GetTopHeadlinesAsync"/> with a category name
/// and receive a list of <see cref="NewsArticle"/> objects.
/// </summary>
public class GNewsService
{
    // Replace this value with your personal API key from https://gnews.io/. The
    // free tier of the API supports up to 100 requests per day. Without a
    // valid API key the app will not be able to fetch live news. To avoid
    // committing a secret to source control, you can set this value from
    // environment variables or secure storage in a production app.
    private const string ApiKey = "YOUR_API_KEY_HERE";

    private static readonly HttpClient _httpClient = new HttpClient();

    /// <summary>
    /// Fetches the top headlines for a given category using the GNews API.
    /// </summary>
    /// <param name="category">The news category (e.g. technology, sports).</param>
    /// <returns>A list of <see cref="NewsArticle"/> instances.</returns>
    /// <exception cref="HttpRequestException">Thrown if the HTTP request fails.</exception>
    public async Task<IList<NewsArticle>> GetTopHeadlinesAsync(string category)
    {
        if (string.IsNullOrWhiteSpace(ApiKey) || ApiKey.Contains("YOUR_API_KEY_HERE", StringComparison.OrdinalIgnoreCase))
        {
            // If no API key has been supplied, return an empty list. In a real
            // application you might throw an exception or log a warning.
            return new List<NewsArticle>();
        }

        // Build the request URL. The API requires a language and category.
        var url = $"https://gnews.io/api/v4/top-headlines?category={category}&lang=en&apikey={ApiKey}";

        // Execute the HTTP request and retrieve the response body as a string.
        var json = await _httpClient.GetStringAsync(url);

        // Deserialize the JSON into our response object. Use case-insensitive
        // property names because the API property names differ in casing.
        var response = JsonSerializer.Deserialize<GNewsResponse>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        // Return the list of articles, or an empty list if none were returned.
        return response?.Articles ?? new List<NewsArticle>();
    }
}