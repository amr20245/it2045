namespace NewsApp.Models;

/// <summary>
/// Represents a single news article retrieved from the GNews API. Note that
/// properties map to the JSON response returned by the API. Additional
/// properties can be added as needed.
/// </summary>
public class NewsArticle
{
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? Content { get; set; }
    public string? ImageUrl { get; set; }
    public string? Url { get; set; }
}