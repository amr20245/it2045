using System.Collections.Generic;

namespace NewsApp.Models;

/// <summary>
/// Represents the top‑level response from the GNews API. The API returns
/// articles in a property named "articles". This class is used to
/// deserialize the JSON response into a C# object graph.
/// </summary>
public class GNewsResponse
{
    public List<NewsArticle> Articles { get; set; } = new();
}