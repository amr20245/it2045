using Microsoft.Extensions.Logging;
using Microsoft.Maui;
using Microsoft.Maui.Hosting;

namespace NewsApp;

/// <summary>
/// The entry point for the .NET MAUI application. This class configures
/// services, fonts, and the application root. It is loosely based on the
/// default MAUI template but stripped back to the essentials required for
/// this assignment.
/// </summary>
public static class MauiProgram
{
    /// <summary>
    /// Creates and configures the MAUI application. You can register
    /// additional services or configure fonts here as needed.
    /// </summary>
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                // Register default fonts. Additional fonts can be added here.
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
        // In debug builds, enable debug logging to assist with troubleshooting.
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}