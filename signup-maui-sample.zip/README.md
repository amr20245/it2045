# Module 7 – Signup and Profile Page Sample (.NET MAUI)

This repository contains a simple .NET MAUI mobile application that demonstrates
URI‑based navigation between a **Signup** page and a **Profile** page. The
application validates user input, passes data between pages using query
parameters, and allows the user to sign out and return to the signup form.

## Project structure

The MAUI application lives in the `SignupApp` folder. Key files include:

| File | Purpose |
| --- | --- |
| `SignupApp/AppShell.xaml` and `.cs` | Defines the navigation shell and registers the route for the profile page |
| `SignupApp/Pages/SignupPage.xaml` | XAML layout for the signup form |
| `SignupApp/Pages/SignupPage.xaml.cs` | Validates input and navigates to the profile page on success |
| `SignupApp/Pages/ProfilePage.xaml` | XAML layout for displaying the user’s information |
| `SignupApp/Pages/ProfilePage.xaml.cs` | Receives query parameters and handles sign‑out navigation |
| `screenshots/screenshots.pdf` | A PDF containing illustrative screenshots of the signup and profile pages on Windows and Android |

The root of the repository also contains `generate_assets.py`, a helper script
that created the illustrative images and assembled them into the PDF in the
`screenshots` folder. This script is not part of the assignment deliverables
but is included for completeness.

## Running the app

To run the application on Windows or Android you will need the .NET MAUI
tooling installed. You can open the solution in **Visual Studio 2026** (or
later) on Windows and run it directly on a Windows machine or an Android
emulator. Alternatively, you can use the .NET CLI:

```bash
# Restore dependencies and build
dotnet build SignupApp/SignupApp.csproj -f net8.0-windows10.0.19041.0

# Run on Windows
dotnet run --project SignupApp/SignupApp.csproj -f net8.0-windows10.0.19041.0

# Run on Android (requires Android SDK and emulator)
dotnet build SignupApp/SignupApp.csproj -t:Run -f net8.0-android
```

When the app starts, enter a username, email, password and confirm password.
If all fields are provided and the passwords match, the app navigates to the
profile page and displays the username and email. Press **Sign Out** to return
to the signup form.

## Screenshots

The `screenshots/screenshots.pdf` document contains four pages:

1. **Windows – Signup:** an illustrative layout showing the signup form running
   on a Windows desktop window.
2. **Windows – Profile:** an illustrative layout showing the profile page on
   Windows after signup.
3. **Android – Signup:** an illustrative layout of the signup form in a mobile
   portrait orientation.
4. **Android – Profile:** an illustrative layout of the profile page on
   Android.

These images demonstrate how the pages should look when you run the app on
different platforms. Feel free to replace them with actual emulator
screenshots when you run your own version of the application.