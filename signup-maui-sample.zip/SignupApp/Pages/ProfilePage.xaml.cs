using System;
using Microsoft.Maui.Controls;

namespace SignupApp.Pages;

/// <summary>
/// The profile page receives user details via query parameters. It displays
/// a confirmation message along with the username and email. The user
/// can sign out and return to the signup page using the sign-out button.
/// </summary>
[QueryProperty(nameof(Username), "username")]
[QueryProperty(nameof(Email), "email")]
public partial class ProfilePage : ContentPage
{
    private string _username = string.Empty;
    private string _email = string.Empty;

    /// <summary>
    /// Gets or sets the username passed from the signup page. The setter
    /// URL-decodes the value and raises property change notifications for
    /// data binding.
    /// </summary>
    public string Username
    {
        get => _username;
        set
        {
            _username = Uri.UnescapeDataString(value ?? string.Empty);
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// Gets or sets the email passed from the signup page. The setter
    /// URL-decodes the value and raises property change notifications for
    /// data binding.
    /// </summary>
    public string Email
    {
        get => _email;
        set
        {
            _email = Uri.UnescapeDataString(value ?? string.Empty);
            OnPropertyChanged();
        }
    }

    public ProfilePage()
    {
        InitializeComponent();
        BindingContext = this;
    }

    private async void OnSignOutClicked(object sender, EventArgs e)
    {
        // Navigate back to the previous page in the navigation stack. Using
        // ".." pops the current page off the stack, returning to signup.
        await Shell.Current.GoToAsync("..", true);
    }
}