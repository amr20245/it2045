using System;
using Microsoft.Maui.Controls;

namespace SignupApp.Pages;

/// <summary>
/// Handles user interactions on the signup page, validates input and
/// navigates to the profile page on successful signup.
/// </summary>
public partial class SignupPage : ContentPage
{
    public SignupPage()
    {
        InitializeComponent();
    }

    private async void OnSignUpClicked(object sender, EventArgs e)
    {
        string username = UsernameEntry?.Text?.Trim();
        string email = EmailEntry?.Text?.Trim();
        string password = PasswordEntry?.Text;
        string confirmPassword = ConfirmPasswordEntry?.Text;

        // Validate that all required fields are provided
        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) ||
            string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
        {
            ErrorLabel.Text = "All fields are required.";
            ErrorLabel.IsVisible = true;
            return;
        }

        // Validate that the password and confirm password match
        if (!string.Equals(password, confirmPassword, StringComparison.Ordinal))
        {
            ErrorLabel.Text = "Password and confirm password must match.";
            ErrorLabel.IsVisible = true;
            return;
        }

        // Clear any previous error
        ErrorLabel.IsVisible = false;

        // Build the navigation route with query parameters. Encode the values
        // to ensure special characters are handled correctly.
        string route = $"ProfilePage?username={Uri.EscapeDataString(username)}&email={Uri.EscapeDataString(email)}";
        await Shell.Current.GoToAsync(route);
    }
}