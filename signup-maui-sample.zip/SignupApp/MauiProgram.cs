using Microsoft.Maui;
using Microsoft.Maui.Hosting;

namespace SignupApp;

/// <summary>
/// Configures and builds the .NET MAUI application. In this simple app we
/// rely on the default configuration provided by the UseMauiApp call.
/// Additional services, fonts and resources can be configured here.
/// </summary>
public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>();

        // Additional configuration (e.g., fonts, services) can be added here

        return builder.Build();
    }
}