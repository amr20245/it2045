using Microsoft.Maui.Controls;

namespace SignupApp;

/// <summary>
/// The root application class. It initializes the app and sets the
/// <see cref="MainPage"/> to an instance of <see cref="AppShell"/>, which
/// configures the navigation routes for this app.
/// </summary>
public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // The main page of the app is the shell, which manages navigation.
        MainPage = new AppShell();
    }
}