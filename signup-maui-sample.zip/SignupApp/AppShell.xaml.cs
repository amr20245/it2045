using Microsoft.Maui.Controls;

namespace SignupApp;

/// <summary>
/// The AppShell is responsible for declaring routes and managing the
/// navigation stack for this sample application. It registers the
/// ProfilePage route to allow URI-based navigation with query parameters.
/// </summary>
public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Register a route for the profile page. This allows navigation
        // using URIs such as "ProfilePage?username=...&email=...".
        Routing.RegisterRoute("ProfilePage", typeof(Pages.ProfilePage));
    }
}